﻿<?php

include_once '../includes/baglan.php';

session_start();

if (isset($_SESSION['GET_USER_SSID'])) {
    echo '<script>window.location.href="../anasayfa.php";</script>';
}

?>

<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excode - V1 > Giriş Sayfası</title>
    <link rel="shortcut icon" type="image/x-icon" href="../app-assets/images/ico/favicon.ico">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.min.css" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/130527/h5ab-snow-flurry.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.all.min.js"></script>

    <style>
        :root {
            --primary-color: #ef4444; 
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0d0d10;
            overflow: hidden; 
            position: relative;
            user-select: none; 
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('makima.jpg'), 
                              linear-gradient(45deg, rgba(0,0,0,.1) 25%, transparent 25%, transparent 75%, rgba(0,0,0,.1) 75%, rgba(0,0,0,.1)),
                              linear-gradient(45deg, rgba(0,0,0,.1) 25%, transparent 25%, transparent 75%, rgba(0,0,0,.1) 75%, rgba(0,0,0,.1));
            background-size: cover, 6px 6px, 6px 6px;
            background-position: center, 0 0, 3px 3px;
            
            filter: brightness(1) grayscale(0.1); 
            opacity: 1; 
            z-index: -2;
            animation: panBackground 60s infinite alternate linear;
        }
        
        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at center, rgba(0,0,0,0.01) 0%, rgba(0,0,0,0.1) 70%, rgba(0,0,0,0.4) 100%);
            z-index: -1;
        }

        input[type="text"], input[type="password"], textarea, select {
            user-select: text !important;
        }

        @keyframes panBackground {
            0% { background-position: 0% 0%; }
            100% { background-position: 100% 100%; }
        }
        
        .excode-logo-text {
            text-shadow: 0 0 15px rgba(239, 68, 68, 0.8), 0 0 30px rgba(239, 68, 68, 0.4);
            animation: text-glow 2s infinite alternate;
        }
        @keyframes text-glow {
            0% { opacity: 0.9; text-shadow: 0 0 10px rgba(239, 68, 68, 0.5); }
            100% { opacity: 1; text-shadow: 0 0 20px rgba(239, 68, 68, 0.9), 0 0 40px rgba(239, 68, 68, 0.5); }
        }

        .sf-snow-flake {
            position: fixed;
            top: -20px;
            z-index: 99999;
        }
        .sf-snow-anim {
            top: 110%;
        }
        .text-primary-custom { color: var(--primary-color); }
        .bg-primary-custom { background-color: var(--primary-color); }

        .login-button {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); 
            box-shadow: 0 10px 25px -5px rgba(239, 68, 68, 0.4);
        }
        .login-button:hover {
            box-shadow: 0 15px 35px -8px rgba(239, 68, 68, 0.6);
            transform: translateY(-2px) scale(1.01);
        }

        .remember-me-checkbox {
            appearance: none;
            width: 1.25rem;
            height: 1.25rem;
            border-radius: 0.375rem; 
            border: 2px solid #475569; 
            background-color: #1e293b; 
            transition: all 0.2s ease-in-out;
            cursor: pointer;
            position: relative;
            flex-shrink: 0;
        }
        .remember-me-checkbox:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .remember-me-checkbox:checked::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0.5rem;
            height: 0.5rem;
            background-color: white;
            border-radius: 50%;
            transform: translate(-50%, -50%);
        }
        .remember-me-checkbox:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.5); 
        }

        .swal2-popup {
            background: #1e293b !important; 
            color: #f1f5f9 !important; 
            border-radius: 0.75rem !important; 
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.2) !important;
        }
        .swal2-title {
            color: #f1f5f9 !important; 
            font-size: 1.75rem !important; 
            font-weight: 700 !important; 
        }
        .swal2-html-container {
            color: #cbd5e1 !important; 
            font-size: 1.125rem !important; 
            margin-top: 0.75rem !important;
        }
        .swal2-confirm {
            background-color: var(--primary-color) !important;
            color: white !important;
            font-weight: 600 !important;
            border-radius: 0.5rem !important;
            padding: 0.75rem 1.5rem !important;
            transition: all 0.2s ease-in-out !important;
        }
        .swal2-confirm:hover {
            background-color: #dc2626 !important; 
            transform: translateY(-1px);
        }
        .swal2-icon.swal2-error [class^=swal2-x-mark-line] {
            background-color: var(--primary-color) !important;
        }
        .swal2-icon.swal2-success .swal2-success-line-tip, 
        .swal2-icon.swal2-success .swal2-success-line-long {
            background-color: var(--primary-color) !important;
        }
        .swal2-icon.swal2-error {
            border-color: var(--primary-color) !important;
        }
        .swal2-icon.swal2-success {
            border-color: var(--primary-color) !important;
        }
    </style>

</head>

<body oncontextmenu="return false;" class="flex items-center justify-center min-h-screen p-4">

    <div id="snow-flurry"></div>
    
    <div class="w-full max-w-sm relative z-10">
        <div class="bg-slate-900/90 backdrop-blur-sm shadow-3xl rounded-2xl p-8 transform transition duration-500 hover:shadow-red-500/50 border border-slate-700/50">
            
            <div class="text-center mb-7">
                <div class="flex items-center justify-center mb-5">
                    <span id="excode-logo" class="excode-logo-text text-primary-custom text-5xl font-black tracking-widest">E<span class="text-slate-100">XCODE</span></span>
                </div>
                <p class="text-slate-300 mt-2 text-sm font-mono tracking-widest bg-slate-800/70 py-1 px-4 rounded-md inline-block">
                    TOKEN: <span class="text-primary-custom font-bold">excode</span>
                </p>
            </div>

            <form id="loginForm" method="POST">
                <div class="space-y-5">
                    
                    <div>
                        <label class="block text-sm font-medium text-slate-300 mb-2" for="token">Token</label>
                        <div class="relative">
                            <input 
                                class="w-full px-4 py-3 text-slate-100 bg-slate-800 border border-slate-700 rounded-lg focus:ring-primary-custom focus:border-primary-custom placeholder-slate-500 transition duration-200 ease-in-out pr-12 text-base" 
                                id="token" 
                                type="password" 
                                name="token" 
                                placeholder="············" 
                                required 
                            />
                            <span class="absolute inset-y-0 right-0 flex items-center pr-4 cursor-pointer text-slate-400 hover:text-primary-custom transition" onclick="togglePasswordVisibility()">
                                <svg id="toggleIcon" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </span>
                        </div>
                    </div>

                    <div class="flex items-center">
                        <input class="remember-me-checkbox" id="remember-me" type="checkbox" tabindex="3" />
                        <label class="ml-3 text-sm text-slate-300 select-none cursor-pointer" for="remember-me">Beni hatırla</label>
                    </div>

                    <button name="login" type="submit" class="login-button w-full text-white font-bold py-3 rounded-xl transition duration-300 ease-in-out">
                        Giriş Yap
                    </button>
                </div>
            </form>
            
        </div>
    </div>

    <script>
        document.onkeydown = function(e) {
            if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i'))) {
                e.preventDefault();
                return false;
            }
            if (e.ctrlKey && e.key === 'u') {
                e.preventDefault();
                return false;
            }
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                return false;
            }
        };

        jQuery(document).ready(function($){
            $(document).snowFlurry({
                maxSize: 35,
                numberOfFlakes: 50,
                minSpeed: 8,
                maxSpeed: 10,
                color: '#fff',
                timeout: 0
            });
        });

        function togglePasswordVisibility() {
            const tokenInput = document.getElementById('token');
            const icon = document.getElementById('toggleIcon');
            if (tokenInput.type === 'password') {
                tokenInput.type = 'text';
                icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7 1.274-4.057 5.064-7 9.542-7 1.258 0 2.474.205 3.597.578m-1.127 1.127a3 3 0 11-4.743-4.743"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 12l2-2m0 0l2 2"></path>';
            } else {
                tokenInput.type = 'password';
                icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>';
            }
        }

        $(document).ready(function() {
            $("#loginForm").submit(function(e) {
                e.preventDefault();
                
                var token = $("#token").val();

                if (token == '') {
                    Swal.fire({
                        title: "Token Gerekli!",
                        html: "<span class='text-lg'>Giriş yapmak için lütfen tokeninizi girin.</span>",
                        icon: "error",
                        confirmButtonText: "Tamam",
                        confirmButtonColor: '#ef4444',
                        background: '#1e293b',
                        customClass: {
                            popup: 'swal2-popup',
                            title: 'swal2-title',
                            htmlContainer: 'swal2-html-container',
                            confirmButton: 'swal2-confirm'
                        }
                    })
                } else {
                    $.ajax({
                        url: 'loginForm.php',
                        type: 'POST',
                        data: $(this).serialize(),
                        success: function(data) {
                            
                            if (data == 'nullToken') {
                                Swal.fire({
                                    title: "Hata!",
                                    html: "<span class='text-lg'>Token alanı boş bırakılamaz.</span>",
                                    icon: "error",
                                    confirmButtonText: "Anladım",
                                    confirmButtonColor: '#ef4444',
                                    background: '#1e293b',
                                    customClass: { popup: 'swal2-popup', title: 'swal2-title', htmlContainer: 'swal2-html-container', confirmButton: 'swal2-confirm' }
                                })
                            } else if (data == 'failedToken') {
                                Swal.fire({
                                    title: "Giriş Başarısız!",
                                    html: "<span class='text-lg'>Token bulunamadı veya geçersiz. Lütfen tekrar deneyin.</span>",
                                    icon: "error",
                                    confirmButtonText: "Tekrar Dene",
                                    confirmButtonColor: '#ef4444',
                                    background: '#1e293b',
                                    customClass: { popup: 'swal2-popup', title: 'swal2-title', htmlContainer: 'swal2-html-container', confirmButton: 'swal2-confirm' }
                                })
                            
                            } else if (data == 'oneTimeLogin') {
                                Swal.fire({
                                    title: "Giriş Engellendi!",
                                    html: "<span class='text-lg'>Hesabınızı başka bir şahıs ile paylaşamazsınız!</span>",
                                    icon: "warning",
                                    confirmButtonText: "Kapat",
                                    confirmButtonColor: '#ef4444',
                                    background: '#1e293b',
                                    customClass: { popup: 'swal2-popup', title: 'swal2-title', htmlContainer: 'swal2-html-container', confirmButton: 'swal2-confirm' }
                                })
                            } else if (data == 'expireToken') {
                                Swal.fire({
                                    title: "Token Süresi Bitti!",
                                    html: "<span class='text-lg'>Bu tokenin süresi bitmiştir. Discord sunucumuz üzerinden iletişime geçebilirsiniz.</span>",
                                    icon: "warning",
                                    confirmButtonText: "Discord",
                                    confirmButtonColor: '#ef4444',
                                    background: '#1e293b',
                                    customClass: { popup: 'swal2-popup', title: 'swal2-title', htmlContainer: 'swal2-html-container', confirmButton: 'swal2-confirm' }
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.open('https://discord.gg/your-discord-link', '_blank'); 
                                    }
                                })
                            } else if (data == 'success') {
                                Swal.fire({
                                    title: "Hoş Geldiniz!",
                                    html: "<span class='text-lg'>Başarılı bir şekilde giriş yapıldı! Yönlendiriliyorsunuz...</span>",
                                    iconHtml: '<img src="https://i.imgur.com/4T5gS4c.gif" class="w-24 h-24 mx-auto mb-4 rounded-full border-4 border-primary-custom" alt="success-gif">', 
                                    showConfirmButton: false,
                                    allowOutsideClick: false,
                                    background: '#1e293b',
                                    timer: 2500,
                                    customClass: { popup: 'swal2-popup', title: 'swal2-title', htmlContainer: 'swal2-html-container' }
                                }).then(() => {
                                    window.location.href = "../anasayfa";
                                })
                            }
                        }
                    })
                }
            })
        })
    </script>
</body>

</html>