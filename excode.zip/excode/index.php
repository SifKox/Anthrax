<?php
$db_host = 'localhost';
$db_user = 'root';
$db_pass = ''; 
$db_name = 'excodev1';

$db_exists_status = false;
$error_message = "";

$conn = @new mysqli($db_host, $db_user, $db_pass);

if ($conn->connect_error) {
    $db_exists_status = false;
    $error_message = "[KRİTİK HATA] Sistem Başlatılamıyor. Lütfen Sunucu Durumunu Kontrol Edin.";
} else {
    $query = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$db_name'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $db_exists_status = true;
        $error_message = "[OK] Konfigürasyon Doğrulandı. Devam Ediliyor...";
    } else {
        $db_exists_status = false;
        $error_message = "[HATA] Sistem Kurulumu Tamamlanmamış.";
    }

    $conn->close();
}

$is_setup_complete_js = json_encode($db_exists_status);
$error_message_js = json_encode($error_message);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXCODE // SYSTEM INITIALIZING</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap');
        
        :root {
            --neon-green: #00ff88;
            --neon-blue: #00aaff;
            --bg-deep-dark: #000000;
            --text-color: #f0f0f0;
        }

        body {
            background-color: var(--bg-deep-dark);
            font-family: 'Orbitron', sans-serif;
            color: var(--text-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
            position: relative;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }

        .glitch-container {
            position: relative;
            display: inline-block;
        }

        .glitch-text {
            color: var(--neon-blue);
            text-shadow: 0 0 10px rgba(0, 170, 255, 0.5);
            animation: text-flicker-subtle 5s linear infinite;
        }

        .glitch-text::before,
        .glitch-text::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--bg-deep-dark);
            clip-path: inset(0 0 0 0);
        }

        .glitch-text::before {
            color: var(--neon-green);
            left: 2px;
            text-shadow: -1px 0 var(--neon-green);
            animation: glitch-anim-1 2s infinite linear alternate-reverse;
        }

        .glitch-text::after {
            color: var(--neon-blue);
            left: -2px;
            text-shadow: 1px 0 var(--neon-blue);
            animation: glitch-anim-2 3s infinite linear alternate-reverse;
        }

        @keyframes text-flicker-subtle {
            0%, 100% { opacity: 1; }
            5% { opacity: 0.95; }
            10% { opacity: 1; }
            50% { opacity: 0.9; }
            55% { opacity: 1; }
        }

        @keyframes glitch-anim-1 {
            0% { clip-path: inset(10% 0 85% 0); }
            10% { clip-path: inset(6% 0 88% 0); }
            30% { clip-path: inset(30% 0 50% 0); }
            50% { clip-path: inset(5% 0 80% 0); }
            70% { clip-path: inset(70% 0 10% 0); }
            90% { clip-path: inset(8% 0 85% 0); }
            100% { clip-path: inset(20% 0 60% 0); }
        }

        @keyframes glitch-anim-2 {
            0% { clip-path: inset(20% 0 70% 0); }
            15% { clip-path: inset(75% 0 15% 0); }
            35% { clip-path: inset(5% 0 80% 0); }
            55% { clip-path: inset(60% 0 30% 0); }
            75% { clip-path: inset(10% 0 85% 0); }
            100% { clip-path: inset(40% 0 40% 0); }
        }

        .scanline-effect {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
            opacity: 0.1;
        }

        .scanline-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--neon-green), transparent);
            box-shadow: 0 0 15px var(--neon-green);
            animation: scan-move 4s linear infinite;
        }

        @keyframes scan-move {
            0% { transform: translateY(0vh); }
            100% { transform: translateY(100vh); }
        }

        .loading-bar-container {
            border: 1px solid rgba(0, 255, 136, 0.4);
            background-color: rgba(10, 10, 15, 0.5);
            box-shadow: 0 0 10px rgba(0, 255, 136, 0.2);
        }

        .loading-bar {
            background: var(--neon-green);
            box-shadow: 0 0 12px var(--neon-green), 0 0 4px var(--neon-green) inset;
            transition: width 0.8s cubic-bezier(0.2, 0.8, 0.5, 1);
        }

        .status-message-active {
            color: var(--neon-green);
            text-shadow: 0 0 5px rgba(0, 255, 136, 0.8), 0 0 15px rgba(0, 255, 136, 0.5);
            transition: color 0.5s ease-in-out;
            opacity: 0;
            animation: text-flash 0.5s ease forwards;
        }

        @keyframes text-flash {
            from { opacity: 0; transform: translateY(5px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes blink { 
            from { opacity: 1.0; } 
            50% { opacity: 0.5; } 
            to { opacity: 1.0; } 
        }

        #callToAction, #setupCallToAction {
            color: var(--neon-blue);
            text-shadow: 0 0 5px var(--neon-blue);
            transition: all 0.3s;
        }
        #callToAction:hover, #setupCallToAction:hover {
            color: var(--neon-green);
            text-shadow: 0 0 10px var(--neon-green);
            transform: scale(1.05);
        }

    </style>
</head>
<body>

    <div class="scanline-effect"></div>

    <div class="p-8 md:p-12 max-w-sm w-11/12 flex flex-col items-center space-y-10 bg-gray-900 bg-opacity-10 rounded-xl border border-gray-900 shadow-3xl relative z-10 backdrop-blur-md">
        
        <div class="flex flex-col items-center space-y-4">
            
            <svg class="w-20 h-20 text-white animate-pulse" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7 8L3 12L7 16" stroke="var(--neon-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M17 8L21 12L17 16" stroke="var(--neon-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M14 4L10 20" stroke="var(--neon-blue)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>

            <div class="glitch-container">
                <h1 id="logoText" data-text="EXCODE" class="glitch-text text-5xl md:text-6xl font-extrabold uppercase tracking-widest text-center">EXCODE</h1>
            </div>
            
            <p class="text-sm text-gray-600 tracking-wider">VERSİYON 1</p>
        </div>

        <div id="statusArea" class="h-6 text-base md:text-xl text-center min-h-[1.5rem] w-full">
            <span class="status-message-active">[CHECK] Sistem başlatma kontrolleri yapılıyor...</span>
        </div>

        <div id="loadingBarContainer" class="loading-bar-container w-full h-1 rounded-full overflow-hidden">
            <div id="progressBar" class="loading-bar h-full rounded-full w-0"></div>
        </div>

        <a href="auth/auth-login" id="callToAction" class="hidden text-lg font-bold uppercase tracking-widest cursor-pointer mt-5">
            SİSTEME GİRİŞ YAP //
        </a>

        <a href="kurulum" id="setupCallToAction" class="hidden text-lg font-bold uppercase tracking-widest cursor-pointer mt-5">
            KURULUM SAYFASINA GİT //
        </a>
        
    </div>

    <script>
        const statusArea = document.getElementById('statusArea');
        const progressBar = document.getElementById('progressBar');
        const logoText = document.getElementById('logoText');
        const callToAction = document.getElementById('callToAction');
        const setupCallToAction = document.getElementById('setupCallToAction');
        const loadingBarContainer = document.getElementById('loadingBarContainer');
        
        const isSetupComplete = <?php echo $is_setup_complete_js; ?>;
        const errorMessage = <?php echo $error_message_js; ?>;
        
        const loadingSteps = [
            { message: "[CORE] Sistem çekirdeği başlatılıyor...", duration: 800, progress: 15 },
            { message: "[NETWORK] Bağlantı protokolleri kuruluyor...", duration: 1000, progress: 35 },
            // Bu adım, başarılı durumda PHP'den gelen konfigürasyon mesajıyla doldurulacak
            { message: "[KONFİG] Gerekli sistem konfigürasyonu kontrol ediliyor...", duration: 1500, progress: 60 },
            { message: "[ASSETS] Kaynaklar önbelleğe alınıyor...", duration: 900, progress: 85 },
            { message: "[INIT] Giriş dizinine yönlendirme hazır...", duration: 1200, progress: 100, final: true }
        ];

        let currentProgress = 0;
        let stepIndex = 0;
        let loadingFinished = false;

        function showSetupPrompt() {
            loadingBarContainer.classList.add('hidden');
            callToAction.classList.add('hidden');
            
            // Hata mesajı '[KRİTİK HATA]' içeriyorsa sadece mesaj gösterilir, kurulum butonu gizlenir.
            const isFatalError = errorMessage.includes("[KRİTİK HATA]");
            
            if (!isFatalError) {
                setupCallToAction.classList.remove('hidden');
            }

            // Hata mesajını PHP'den alınan değere ayarla
            const errorClass = isFatalError ? 'text-red-700' : 'text-red-500';
            // Sadece PHP'den gelen mesajı göster
            statusArea.innerHTML = `<span class="status-message-active ${errorClass}">${errorMessage.replace(/\[HATA\]|\[KRİTİK HATA\]/g, '').trim()}</span>`;
            
            const errorSpan = statusArea.querySelector('span');
            if (errorSpan) {
                errorSpan.style.animation = 'text-flash 0.5s ease forwards, blink 1s step-end infinite 2s';
            }
        }

        function runLoadingSequence() {
             // Sadece başarılı mesajın içeriğini (örn: Konfigürasyon Doğrulandı. Devam Ediliyor...) 3. adıma yerleştir
            loadingSteps[2].message = errorMessage.replace(/\[OK\]/g, '').trim(); 
            
            if (stepIndex < loadingSteps.length) {
                const step = loadingSteps[stepIndex];
                
                currentProgress = step.progress;
                progressBar.style.width = currentProgress + '%';

                statusArea.innerHTML = `<span class="status-message-active">${step.message}</span>`;
                
                if (currentProgress > 50) {
                    logoText.style.color = 'var(--neon-green)';
                } else {
                    logoText.style.color = 'var(--neon-blue)';
                }
                
                setTimeout(() => {
                    stepIndex++;
                    runLoadingSequence();
                }, step.duration);

            } else if (!loadingFinished) {
                loadingFinished = true;
                progressBar.style.width = '100%';
                statusArea.innerHTML = `<span class="status-message-active">[COMPLETE] GİRİŞ İÇİN İZNİNİZ VAR.</span>`;
                setTimeout(() => {
                    callToAction.classList.remove('hidden');
                }, 1000);
            }
        }

        function startSystemCheck() {
            console.log(`[PHP CHECK] Status: ${isSetupComplete ? 'OK' : 'FAIL'}`);
            
            setTimeout(() => {
                if (isSetupComplete) {
                    runLoadingSequence();
                } else {
                    showSetupPrompt();
                }
            }, 500); 
        }

        document.addEventListener('contextmenu', e => e.preventDefault());
        document.onkeydown = function(e) {
            if (e.keyCode === 123 || (e.ctrlKey && e.keyCode === 83) || (e.ctrlKey && e.keyCode === 85)) {
                e.preventDefault();
                return false;
            }
        };

        window.onload = startSystemCheck;

    </script>
</body>
</html>