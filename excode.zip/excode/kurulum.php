<?php
error_reporting(0);
ini_set('display_errors', 0);

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'excodev1';

$status = 'PENDING';
$message = 'Kurulum işlemi başlatılıyor...';
$is_redirect = false;

$sql_content = <<<SQL
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 10 Kas 2025, 03:57:42
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `excodev1`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `news`
--

INSERT INTO `news` (`id`, `date`, `content`) VALUES
(43, '10.11.25 04:03:24', 'Telegram Kanalımız; t.me/excodexx\r\nDiscord Adresimiz; discord.gg/excodex');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `token` varchar(255) NOT NULL,
  `last_ip` varchar(69) NOT NULL,
  `last_login` varchar(69) NOT NULL,
  `expire_date` varchar(69) NOT NULL,
  `access_level` int(11) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `nick_color` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`uid`, `username`, `token`, `last_ip`, `last_login`, `expire_date`, `access_level`, `profile_image`, `nick_color`) VALUES
(1, 'Excode', 'excode', '', '', '275760-09-09', 3, 'https://i.pinimg.com/564x/9e/d1/20/9ed1201d7f270cbde3a25b21c836c9bd.jpg', '#bbff00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `whitelist`
--

CREATE TABLE `whitelist` (
  `id` int(11) NOT NULL,
  `tc` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `whitelist`
--

INSERT INTO `whitelist` (`id`, `tc`) VALUES
(21, 'NTA4NjAyMDg3NDA='),
(22, 'MTA4ODM1Mjc2MDA='),
(23, 'ZTE4NzUyYjI0ZWMwNjE3NzZlYmVhMjY0ZGQ2ZWJiMTI=');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `uid` (`uid`);

--
-- Tablo için indeksler `whitelist`
--
ALTER TABLE `whitelist`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2913;

--
-- Tablo için AUTO_INCREMENT değeri `whitelist`
--
ALTER TABLE `whitelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
SQL;


try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?");
    $stmt->execute([$dbname]);
    $dbExists = $stmt->fetchColumn();

    if ($dbExists) {
        $status = 'INSTALLED';
        $message = "Kurulum daha önce yapılmış! Tekrar kurulum yapılamaz.";
    } else {
        $message = "Kurulum başlatılıyor...";
        
        $pdo->exec("CREATE DATABASE `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $message = "Kurulum devam ediyor...";

        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $pdo->exec($sql_content);


        $status = 'SUCCESS';
        $message = "Kurulum başarıyla tamamlandı!";
        $is_redirect = true;
    }

} catch (PDOException $e) {
    $status = 'ERROR';
    if (strpos($e->getMessage(), 'SQLSTATE[HY000] [2002]') !== false) {
        $message = "HATA: Veritabanına bağlanılamadı. XAMPP/MySQL çalışmıyor olabilir VEYE bağlantı bilgileri yanlış.";
    } else {
        $message = "Veritabanı bağlantı/işlem hatası.";
    }
} catch (Exception $e) {
    $status = 'ERROR';
    $message = "Kurulum Hatası.";
}

$color = '';
$icon = '';
switch ($status) {
    case 'SUCCESS':
        $color = 'text-green-400 border-green-500 bg-green-900/20';
        $icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>';
        break;
    case 'INSTALLED':
        $color = 'text-yellow-400 border-yellow-500 bg-yellow-900/20';
        $icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.3 16c-.77 1.333.192 3 1.732 3z" /></svg>';
        break;
    case 'ERROR':
        $color = 'text-red-400 border-red-500 bg-red-900/20';
        $icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>';
        break;
    default:
        $color = 'text-gray-400 border-gray-500 bg-gray-900/20';
        $icon = '<svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>';
        break;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excode v1 - Kurulum Sayfası</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #000000;
            color: #E5E7EB;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }
        .card {
            background-color: #0A0A0A;
            box-shadow: 0 0 30px rgba(76, 81, 191, 0.3);
            border: 1px solid #1A1A1A;
        }
        .excode-title {
            font-size: 2.5rem;
            font-weight: 800;
            letter-spacing: -0.05em;
            color: #4C51BF;
            text-shadow: 0 0 15px rgba(76, 81, 191, 0.5);
        }
    </style>
    <?php if ($is_redirect): ?>
    <script>
        setTimeout(() => {
            window.location.href = '/'; 
        }, 2000);
    </script>
    <?php endif; ?>
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.addEventListener('keydown', event => {
            if ((event.ctrlKey || event.metaKey) && (event.key === 'u' || event.key === 's')) {
                event.preventDefault();
            }
            if (event.key === 'F12' || (event.ctrlKey && event.shiftKey && (event.key === 'I' || event.key === 'J' || event.key === 'C'))) {
                event.preventDefault();
            }
        });
        
        document.addEventListener('selectstart', event => event.preventDefault());
        document.addEventListener('copy', event => event.preventDefault());
    </script>
</head>
<body>

<div class="card w-full max-w-lg p-8 rounded-xl space-y-6">
    <div class="text-center">
        <h1 class="excode-title mb-1">EXCODE V1</h1>
        <p class="text-gray-400 text-sm">KURULUM EKRANI</p>
    </div>

    <div class="p-5 rounded-lg border-2 <?php echo $color; ?> transition duration-300">
        <div class="flex items-start space-x-4">
            <div class="flex-shrink-0 mt-1">
                <?php echo $icon; ?>
            </div>
            <div>
                <h2 class="text-xl font-bold mb-2">
                    <?php 
                        if ($status == 'SUCCESS') echo 'KURULUM BAŞARILI';
                        else if ($status == 'INSTALLED') echo 'KURULUM ZATEN YAPILMIŞ';
                        else if ($status == 'ERROR') echo 'SİSTEM HATASI';
                        else echo 'İŞLEM BEKLİYOR';
                    ?>
                </h2>
                <p class="text-sm font-light leading-relaxed">
                    <?php echo $message; ?>
                </p>
                
                <?php if ($status == 'SUCCESS'): ?>
                    <p class="mt-3 text-sm font-semibold">
                        Yönlendiriliyor... (2 saniye)
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
</div>

</body>
</html>