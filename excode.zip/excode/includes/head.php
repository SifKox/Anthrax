<meta charset="utf-8" />
        <title>DeDChecker - İstihbarat Grubu</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="TeamDeD">
        <meta name="keywords" content="dedchecker, ded checker, ded, checker, credit card, credit card checker, ccn, ccn checker, cc checker, tr checker, tr cc checker, usa cc checker, card checker, bin, bin checker, cc duzenleyici, mernis, mernis 2021, kisi sorgu, kisi sorgu 2021, tc kimlik sorgu, tc sorgu, tc sorgu 2021, numara sorgu, numara sorgu 2021, kimlik sorgu, kisi bul 2021"/>
		<meta name="description" content="DeDChecker, Piyasanın en iyi ve en hızlı cc checker sitesidir. Data düzeltici, Account checker, Bin checker vb. birçok hizmeti ücretsiz sağlamaktadır. https://discord.gg/U7e7zbfZmG"/>
     <link rel="shortcut icon" href="assets/images/ded/ded.png" type="image/x-icon">

        <link href="assets/css/bootstrap-dark.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app-dark.min.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/shadow.css" rel="stylesheet" type="text/css" />
				<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />