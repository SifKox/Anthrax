<?php
include 'baglan.php';

session_start();

$GET_USERNAME = $_SESSION['GET_USER_SSID'];

$USERNAMEQUERY = $db->query("SELECT * FROM users WHERE token = '$GET_USERNAME'");

while ($USERNAMEDATA = $USERNAMEQUERY->fetch()) {
    $NICKNAME = $USERNAMEDATA['username'];
    $CHECKUSERACCESS = $USERNAMEDATA['access_level'];
}

$domainw = $_SERVER['SERVER_NAME'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excoder</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        'primary-dark': '#1e293b',
                        'secondary-dark': '#334155',
                        'accent': '#38bdf8',
                        'text-primary': '#e2e8f0',
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0f172a;
            color: #f8fafc;
        }

        /* Kar Tanesi CSS'i */
        .sf-snow-flake {
            position: fixed;
            top: -20px;
            z-index: 99999;
        }
        .sf-snow-anim {
            top: 110%;
        }

        .sidebar-content-scroll::-webkit-scrollbar {
            width: 8px; 
        }
        .sidebar-content-scroll::-webkit-scrollbar-thumb {
            background-color: #475569;
            border-radius: 10px;
        }
        .sidebar-content-scroll::-webkit-scrollbar-track {
            background: transparent;
        }

        .navigation-header {
            padding: 1rem 0;
            margin-top: 1.5rem;
            border-top: 1px solid rgba(71, 85, 105, 0.5);
            text-align: center;
        }

        .menu-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 14px 0px;
            margin-top: 8px; 
            border-radius: 0.25rem; 
            font-weight: 500;
            color: #e2e8f0;
            transition: all 0.2s ease;
            text-decoration: none;
            width: 100%;
            height: 80px; 
            font-size: 0.95rem; 
            line-height: 1.2; 
            text-align: center;
        }
        
        .menu-link svg {
            margin-right: 0;
            margin-bottom: 4px;
            opacity: 0.9; 
            width: 24px;
            height: 24px;
        }
        
        .menu-link .menu-title {
            white-space: normal;
        }

        .menu-link.admin-button {
            flex-direction: row; 
            height: auto; 
            padding: 16px 16px; 
            background-color: #38bdf8;
            color: #0f172a;
            font-weight: 600;
            margin-top: 16px; 
            border-radius: 0.5rem;
        }
        .menu-link.admin-button svg {
            margin-right: 12px;
            margin-bottom: 0;
            color: #0f172a;
        }

        .menu-link.admin-button:hover {
            background-color: #0ea5e9;
        }
        
        .menu-link.is-active:not(.admin-button) {
            background-color: #334155; 
            color: #38bdf8; 
            font-weight: 600;
        }
        .menu-link.is-active:not(.admin-button) svg {
            color: #38bdf8;
            opacity: 1;
        }

        .menu-link:hover:not(.admin-button) {
            background-color: #334155;
            color: #ffffff;
        }
        
        #sidebar {
            padding: 0;
        }
        .logo-section {
            padding: 1rem; 
        }

    </style>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/130527/h5ab-snow-flurry.js"></script>
</head>

<body>
    <div id="sidebar" class="fixed top-0 left-0 h-full w-64 bg-primary-dark shadow-2xl z-30">
        
        <div class="flex items-center justify-center h-16 mb-4 border-b border-gray-700/50 logo-section">
            <a href="anasayfa" class="flex items-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="16 18 22 12 16 6"></polyline>
                    <polyline points="8 6 2 12 8 18"></polyline>
                </svg>
                <h2 class="text-2xl font-extrabold text-white tracking-wider">Ex<span class="text-accent">code</span></h2>
            </a>
        </div>

        <div class="h-[calc(100vh-80px)] overflow-y-auto sidebar-content-scroll px-4">
            <ul id="main-menu-navigation" class="space-y-1">
                
                <li class="nav-item">
                    <a href="anasayfa" class="menu-link group">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span class="menu-title">Ana Sayfa</span>
                    </a>
                </li>
                
                <li class="navigation-header text-xs font-semibold uppercase text-gray-400">
                    Sorgu Çözümleri
                </li>
                
                <li class="nav-item">
                    <a href="adsoyadsorgu" class="menu-link group">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        <span class="menu-title">Ad Soyad Sorgu</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="tcsorgu" class="menu-link group">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="8" x2="22" y2="12"></line><line x1="22" y1="8" x2="18" y2="12"></line></svg>
                        <span class="menu-title">TC Sorgu</span>
                    </a>
                </li>
                
                <li class="navigation-header text-xs font-semibold uppercase text-gray-400">
                    Numara Çözümleri
                </li>
                
                <li class="nav-item">
                    <a href="gsmtc" class="menu-link group">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                        <span class="menu-title">GSM'den TC</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="tcgsm" class="menu-link group">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2 2-20.94 20.94 0 0 1-20.3-20.3A2 2 0 0 1 3.08 2h3a2 2 0 0 1 2 1.74 15.68 15.68 0 0 0 .1 2.82.7.7 0 0 1-.16.63L6.16 8.16a13 13 0 0 0 8.7 8.7l1.32-1.28a.7.7 0 0 1 .63-.16 15.68 15.68 0 0 0 2.82.1A2 2 0 0 1 22 16.92z"></path></svg>
                        <span class="menu-title">TC'den GSM</span>
                    </a>
                </li>
                
                <li class="navigation-header text-xs font-semibold uppercase text-gray-400">
                    İnternet Çözümleri
                </li>
                
                <li class="nav-item">
                    <a href="discord" class="menu-link group">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                        <span class="menu-title">Discord ID Sorgu</span>
                    </a>
                </li>
                
                
                <?php
                if ($CHECKUSERACCESS >= 1) {
                ?>
                <li class="navigation-header text-xs font-semibold uppercase text-red-400">
                    Admin Panel
                </li>
                <li class="nav-item">
                    <a class="menu-link group admin-button" href="admin-news">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                        <span class="menu-title">Duyurular</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="menu-link group" href="admin-users">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        <span class="menu-title">Kullanıcı Yönetimi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="menu-link group" href="admin-user-add">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="8" x2="18" y2="14"></line><line x1="21" y1="11" x2="15" y2="11"></line></svg>
                        <span class="menu-title">Kullanıcı Ekle</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="menu-link group" href="admin-ban">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
                        <span class="menu-title">Ban Yönetimi</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="menu-link group" href="admin-whitelist">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21.5c-4.97 0-9-4.03-9-9s4.03-9 9-9 9 4.03 9 9-4.03 9-9 9z"></path><path d="M12 17c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5z"></path></svg>
                        <span class="menu-title">Whitelist Yönetimi</span>
                    </a>
                </li>
                <?php
                }
                ?>
            </ul>
        </div>
    </div>
    
    <script>
        function setActiveLink() {
            let path = window.location.pathname.split('/').pop().replace('.php', '').replace('.html', '');
            if (!path) {
                path = 'anasayfa';
            }

            const menuLinks = document.querySelectorAll('.nav-item a');

            menuLinks.forEach(link => {
                link.classList.remove('is-active');

                const linkPath = link.getAttribute('href');

                if (linkPath === path) {
                    link.classList.add('is-active');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', setActiveLink);
    </script>
    
    <script>
        jQuery(document).ready(function($){
            $(document).snowFlurry({
                maxSize: 6,
                numberOfFlakes: 50,
                minSpeed: 8,
                maxSpeed: 10,
                color: '#fff',
                timeout: 0
            });
        });
    </script>
</body>
</html>