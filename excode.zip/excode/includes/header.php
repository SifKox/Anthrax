<?php

include 'baglan.php';

session_start();

$GET_USERNAME = $_SESSION['GET_USER_SSID'];

$USERNAMEQUERY = $db->query("SELECT * FROM users WHERE token = '$GET_USERNAME'");

while ($USERNAMEDATA = $USERNAMEQUERY->fetch()) {
    $NICKNAME = $USERNAMEDATA['username'];
    $CHECKUSERACCESS = $USERNAMEDATA['access_level'];
    $nickcolor = $USERNAMEDATA['nick_color'];
    $profileimage = $USERNAMEDATA['profile_image'];
}

$domainw = $_SERVER['SERVER_NAME'];

if ($CHECKUSERACCESS >= 1) {
    $USERACCESS = "Admin";
} else if ($CHECKUSERACCESS == "-1") {
    header("Location: https://$domainw/auth/banned");
    exit();
} else {
    $USERACCESS = "Kullanıcı";
}

?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<script type="module">import devtools from '../js/node_modules/devtools-detect/index.js'; console.clear();</script>
<script src="https://use.fontawesome.com/452826394c.js"></script>
<noscript><meta http-equiv="refresh" content="0; url=404.html" /></noscript>

<style>
:root {
    --bg-color: #171a21;
    --navbar-content-bg: rgba(25, 29, 40, 0.95);
    --text-color: #e5e7eb;
    --secondary-text: #9ca3af;
    --border-color: rgba(255, 255, 255, 0.1);
    --shadow-dark: 0 4px 15px rgba(0, 0, 0, 0.5);
    --blue: #0096FF;
    --discord: #7289da;
    --telegram: #0088CC;
    --logout: #FF0000;
    --logo-color-start: #785EEF;
    --logo-color-end: #0096FF;
}
body{
    font-family:'Poppins',sans-serif;
    cursor:default;
    background-color:var(--bg-color);
    color:var(--text-color);
    -webkit-user-select:none;
    -moz-user-select:none;
    -ms-user-select:none;
    user-select:none;
    margin: 0;
    padding-top: 70px;
}
input,textarea{
    -webkit-user-select:auto!important;
    -moz-user-select:auto!important;
    -ms-user-select:auto!important;
    user-select:auto!important;
    cursor:text!important;
}

.modern-navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1030;
    background-color: transparent;
    display: flex;
    justify-content: center;
    height: 70px;
}

.navbar-content-wrapper {
    width: 100%;
    max-width: 1200px;
    height: 60px;
    margin: 5px 15px 0 15px;
    
    background-color: var(--navbar-content-bg);
    backdrop-filter: blur(12px);
    box-shadow: var(--shadow-dark);
    border-radius: 12px;
    
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 1.5rem;
}

.navbar-logo {
    font-size: 1.3rem;
    font-weight: 700;
    text-decoration: none;
    color: var(--text-color);
    display: flex;
    align-items: center;
}
.logo-text-effect {
    background: linear-gradient(90deg, var(--logo-color-start) 0%, var(--logo-color-end) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    color: transparent;
}

.navbar-center-group {
    display: none;
    gap: 0.5rem;
    align-items: center;
}
@media (min-width: 992px) {
    .navbar-center-group {
        display: flex;
    }
}

.nav-item a.btn-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    transition: all .2s cubic-bezier(.4,0,.2,1);
    color: var(--text-color);
}
.nav-item a.btn-icon:hover {
    transform: translateY(-1px);
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
}

.nav-item:nth-child(1) a.btn-icon { color: var(--blue); background-color: rgba(0, 150, 255, 0.15); }
.nav-item:nth-child(2) a.btn-icon { color: var(--discord); background-color: rgba(114, 137, 218, 0.15); }
.nav-item:nth-child(3) a.btn-icon { color: var(--telegram); background-color: rgba(0, 136, 204, 0.15); }

.nav-right-group {
    display: flex;
    align-items: center;
}

.dropdown-language a {
    border: 1px solid var(--border-color) !important;
    border-radius: 8px !important;
    padding: 0.3rem 0.6rem !important;
    background-color: rgba(255, 255, 255, 0.05);
    font-size: 0.85rem;
    transition: background-color .2s ease;
}

/* İKİNCİ OK SORUNUNU ÇÖZMEK İÇİN KRİTİK CSS */
.dropdown-user-link.dropdown-toggle::after {
    display: none !important; /* Bootstrap'in otomatik eklediği oku kaldırır */
}

.dropdown-user-link {
    padding: 0.25rem 0.5rem !important;
    border-radius: 10px;
    display: flex;
    align-items: center;
    margin-left: 0.5rem;
    transition: background-color .2s ease;
}
.dropdown-user-link:hover {
    background-color: rgba(255, 255, 255, 0.08);
}

.user-nav {
    line-height: 1.2;
    margin-right: 0.75rem;
    text-align: right;
}
.user-name {
    font-weight: 600 !important;
    font-size: 0.9rem;
    display: block;
    white-space: nowrap;
}
.user-status {
    color: var(--secondary-text) !important;
    font-size: 0.7rem !important;
    display: block;
}

.avatar img.round {
    border-radius: 50%;
    border: 2px solid rgba(255, 255, 255, 0.15);
    width: 34px;
    height: 34px;
    object-fit: cover;
}

[data-feather] {
    width: 18px;
    height: 18px;
}
.dropdown-menu {
    border-radius: 10px !important;
    border: none !important;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4) !important;
    background-color: #252936 !important;
    margin-top: 8px !important;
}
</style>

<script id="Protection">
    document.addEventListener('contextmenu', e=>e.preventDefault());
    document.addEventListener('selectstart', e=>{if(e.target.tagName!=='INPUT'&&e.target.tagName!=='TEXTAREA'){e.preventDefault()}});
    document.addEventListener('dragstart', e=>{if(e.target.tagName==='IMG'){e.preventDefault()}});
    document.onkeydown=e=>{
        if(e.keyCode==123)return false;
        if(e.ctrlKey&&e.shiftKey&&e.keyCode==73)return false;
        if(e.ctrlKey&&e.shiftKey&&e.keyCode==74)return false;
        if(e.ctrlKey&&e.keyCode==83)return false;
        if(e.ctrlKey&&e.keyCode==85)return false;
    }
</script>

<body class="vertical-layout vertical-menu-modern navbar-static footer-static" data-open="click" data-menu="vertical-menu-modern" data-col="">
    <nav class="modern-navbar">
        <div class="navbar-content-wrapper">
            
            <a href="anasayfa" class="navbar-logo">
                <span class="logo-text-effect">Excode</span>
            </a>

            <ul class="navbar-center-group nav">
                <li class="nav-item">
                    <a class="btn-icon" href="anasayfa" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ana Sayfa">
                        <i data-feather="home"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="btn-icon" href="https://discord.com/invite/excodex" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discord">
                        <i data-feather="message-circle"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="btn-icon" href="https://t.me/excodexx" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Telegram">
                        <i data-feather="send"></i>
                    </a>
                </li>
            </ul>
            
            <ul class="nav nav-right-group">
                
                <li class="nav-item dropdown dropdown-language d-none d-lg-block">
                    <a class="nav-link dropdown-toggle" id="dropdown-flag" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="flag-icon flag-icon-tr"></i><span class="selected-language ms-50">TR</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdown-flag">
                        <a class="dropdown-item" href="#"><i class="flag-icon flag-icon-tr me-50"></i> Türkçe</a>
                    </div>
                </li>
                
                <li class="nav-item dropdown dropdown-user">
                    <a class="nav-link dropdown-toggle dropdown-user-link" id="dropdown-user" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="user-nav d-sm-block d-none">
                            <?php
                            if ($nickcolor != "") {
                                echo "<span class='user-name text-truncate' style='color: $nickcolor;'>$NICKNAME</span>";
                            } else {
                                echo "<span class='user-name text-truncate'>$NICKNAME</span>";
                            }
                            ?>
                            <small class="user-status text-muted"><?= $USERACCESS; ?></small>
                        </div>
                        <span class="avatar">
                            <?php
                            if ($profileimage != "") {
                                echo "<img class='round' src='$profileimage' alt='profile avatar'>";
                            } else {
                                echo "<img class='round' src='salam/kullanici.jpg' alt='profile avatar'>";
                            }
                            ?>
                            <span class="avatar-status-online"></span>
                        </span>
                        <i data-feather="chevron-down" style="width: 14px; height: 14px; margin-left: 5px;"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdown-user">
                        <a class="dropdown-item" href="myaccount"><i class="me-50" data-feather="edit"></i> Hesabım</a>
                        <a class="dropdown-item" href="cikis"><i class="me-50" data-feather="power"></i> Çıkış Yap</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</body>

<script>
    if (typeof feather !== 'undefined') {
        feather.replace({ width: 18, height: 18 });
    }
</script>